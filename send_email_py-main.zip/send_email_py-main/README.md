# send_email_simple

Description.

Send emails with app Outlook with Python.

## Installing

Use de pack manager [pip](https://pip.pypa.io/en/stable/) to install send_email_simple


pip install -i https://test.pypi.org/simple/ send-simple-email


## Usage


from package_name import enviar_email_com_python

enviar_email_com_python.enviar_email()


## Author

Marcos Eduardo
